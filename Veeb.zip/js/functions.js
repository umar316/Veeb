//For adding custom interactions

$(document).ready(function(){

});